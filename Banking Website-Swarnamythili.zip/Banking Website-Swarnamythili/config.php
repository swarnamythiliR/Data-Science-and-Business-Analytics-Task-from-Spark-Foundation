<?php

	$conn = mysqli_connect('localhost','id16993294_root','Swarna@123456','id16993294_banking');

	if(!$conn){
		die("Could not connect to the database due to the following error --> ".mysqli_connect_error());
	}

?>